import React, { useState, useEffect } from 'react';
import "./App.css";
import { quizData } from './quizData';
import ModuleSelection from './components/ModuleSelection';
import SectionSelection from './components/SectionSelection';
import QuizInterface from './components/QuizInterface';
import Results from './components/Results';

// ── localStorage helpers ─────────────────────────────────────
const STORAGE_KEY = 'cybershield_quiz_state';

const saveState = (state) => {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch (e) {
    console.warn('Could not save quiz state:', e);
  }
};

const loadState = () => {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch (e) {
    return null;
  }
};

const clearState = () => {
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch (e) {}
};

// ─────────────────────────────────────────────────────────────

function App() {
  // Load saved state on first mount
  const saved = loadState();

  const [currentView,     setCurrentView]     = useState(saved?.currentView     || 'modules');
  const [selectedModule,  setSelectedModule]  = useState(saved?.selectedModule  || null);
  const [selectedSection, setSelectedSection] = useState(saved?.selectedSection || null);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers,         setAnswers]         = useState({});
  const [moduleAnswers,   setModuleAnswers]   = useState(saved?.moduleAnswers   || {});
  const [timeSpent,       setTimeSpent]       = useState(saved?.timeSpent       || 0);

  // ── Timer ─────────────────────────────────────────────────
  useEffect(() => {
    let interval;
    if (currentView === 'quiz') {
      interval = setInterval(() => {
        setTimeSpent(prev => prev + 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [currentView]);

  // ── Persist key state to localStorage on every change ────
  useEffect(() => {
    // Only save when something meaningful is selected
    if (selectedModule) {
      saveState({
        currentView,
        selectedModule,
        selectedSection,
        moduleAnswers,
        timeSpent,
      });
    }
  }, [currentView, selectedModule, selectedSection, moduleAnswers, timeSpent]);

  // ── Handlers ─────────────────────────────────────────────

  const handleModuleSelect = (moduleId) => {
    // Load any existing progress for THIS module from localStorage
    const existing = loadState();
    const existingAnswers = existing?.selectedModule === moduleId
      ? (existing?.moduleAnswers || {})
      : {};

    setSelectedModule(moduleId);
    setCurrentView('sections');
    setAnswers({});
    setModuleAnswers(existingAnswers); // preserve existing progress
    // Don't reset timeSpent if resuming same module
    if (existing?.selectedModule !== moduleId) {
      setTimeSpent(0);
    }
  };

  const handleSectionSelect = (sectionId) => {
    setSelectedSection(sectionId);
    setCurrentView('quiz');
    setCurrentQuestion(0);
    setAnswers({});
  };

  const handleAnswer = (questionId, answer) => {
    setAnswers(prev => ({ ...prev, [questionId]: answer }));
  };

  const handleNextQuestion = () => {
    const questions = getCurrentQuestions();
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(prev => prev + 1);
    }
  };

  const handlePrevQuestion = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(prev => prev - 1);
    }
  };

  const handleFinishSection = () => {
    const sectionKey = `module${selectedModule}_section${selectedSection}`;

    const updatedModuleAnswers = {
      ...moduleAnswers,
      [sectionKey]: { ...answers }
    };

    setModuleAnswers(updatedModuleAnswers);

    const module = quizData.modules.find(m => m.id === selectedModule);
    const totalSections = module ? module.sections.length : 4;

    const completedCount = Object.keys(updatedModuleAnswers).filter(key =>
      key.startsWith(`module${selectedModule}`)
    ).length;

    if (completedCount >= totalSections) {
      // ✅ All sections done — go to results
      setCurrentView('results');
      // Save final state before showing results
      saveState({
        currentView: 'results',
        selectedModule,
        selectedSection,
        moduleAnswers: updatedModuleAnswers,
        timeSpent,
      });
    } else {
      setCurrentView('sections');
    }

    setAnswers({});
  };

  const handleBackToSections = () => {
    setCurrentView('sections');
    setCurrentQuestion(0);
    setAnswers({});
  };

  const handleBackToModules = () => {
    // Clear all state — user is going back to start fresh
    clearState();
    setCurrentView('modules');
    setSelectedModule(null);
    setSelectedSection(null);
    setAnswers({});
    setModuleAnswers({});
    setTimeSpent(0);
  };

  const getCurrentQuestions = () => {
    if (!selectedModule || !selectedSection) return [];
    const module = quizData.modules.find(m => m.id === selectedModule);
    if (!module) return [];
    const section = module.sections.find(s => s.id === selectedSection);
    return section ? section.questions : [];
  };

  return (
    <div className="quiz-app">
      <div className="stars-background"></div>

      {currentView === 'modules' && (
        <ModuleSelection
          modules={quizData.modules}
          onSelectModule={handleModuleSelect}
        />
      )}

      {currentView === 'sections' && (
        <SectionSelection
          module={quizData.modules.find(m => m.id === selectedModule)}
          onSelectSection={handleSectionSelect}
          onBack={handleBackToModules}
          completedSections={Object.keys(moduleAnswers).filter(key =>
            key.startsWith(`module${selectedModule}`)
          )}
        />
      )}

      {currentView === 'quiz' && (
        <QuizInterface
          questions={getCurrentQuestions()}
          currentQuestion={currentQuestion}
          answers={answers}
          onAnswer={handleAnswer}
          onNext={handleNextQuestion}
          onPrev={handlePrevQuestion}
          onFinish={handleFinishSection}
          onBack={handleBackToSections}
          moduleTitle={quizData.modules.find(m => m.id === selectedModule)?.title}
          sectionNumber={selectedSection}
          totalSections={quizData.modules.find(m => m.id === selectedModule)?.sections?.length ?? 4}
          onSectionReviewComplete={() => {}}
        />
      )}

      {currentView === 'results' && (
        <Results
          module={quizData.modules.find(m => m.id === selectedModule)}
          moduleAnswers={moduleAnswers}
          onBackToModules={handleBackToModules}
          timeSpent={timeSpent}
        />
      )}
    </div>
  );
}

export default App;